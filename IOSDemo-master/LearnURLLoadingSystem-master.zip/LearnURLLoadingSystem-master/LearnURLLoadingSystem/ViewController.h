//
//  ViewController.h
//  LearnURLLoadingSystem
//
//  Created by Amay on 10/18/15.
//  Copyright © 2015 Beddup. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

