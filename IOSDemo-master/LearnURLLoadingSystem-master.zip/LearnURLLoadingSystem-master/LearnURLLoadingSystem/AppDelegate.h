//
//  AppDelegate.h
//  LearnURLLoadingSystem
//
//  Created by Amay on 10/18/15.
//  Copyright © 2015 Beddup. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

