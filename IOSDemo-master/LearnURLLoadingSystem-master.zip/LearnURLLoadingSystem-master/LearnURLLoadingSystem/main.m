//
//  main.m
//  LearnURLLoadingSystem
//
//  Created by Amay on 10/18/15.
//  Copyright © 2015 Beddup. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
